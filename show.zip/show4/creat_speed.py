s_p_l = 10
s_p_h = 26
s_n_h = 17
h_p_l = 3
h_p_h = 8
h_n_h = 6

s
