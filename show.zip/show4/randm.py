import random
import numpy as np


for i in range(12):
    a=np.random.standard_normal()
    print(a)